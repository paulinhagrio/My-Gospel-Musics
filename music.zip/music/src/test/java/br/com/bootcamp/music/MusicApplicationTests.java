package br.com.bootcamp.music;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicApplicationTests {

	@Test
	void contextLoads() {
	}

}
